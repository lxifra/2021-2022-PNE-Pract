d = {"A": "hola", "B": "adiós"}
print(d["A"])
print(d.values()) #hola #adiós
print(d.items()) #(A,
print(d.keys())
print(d.keys())